package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
    public static void main(String[] args)
    {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.com.tr/");
        driver.manage().window().maximize();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }
123Asd123.
        driver.findElement(By.xpath("//input[@name='accept']")).click();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        JavascriptExecutor jd = (JavascriptExecutor) driver;
        jd.executeScript("window.scrollTo(0,1500)");

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//img[@alt='Kitap']")).click();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//img[@alt='Kızıl Veba']")).click();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        JavascriptExecutor kd = (JavascriptExecutor) driver;
        kd.executeScript("window.scrollTo(0,250)");

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//span[@id='atc-declarative']//span[@id='submit.add-to-cart']")).click();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//a[@href='/cart?ref_=sw_gtc']")).click();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.quit();
    }
}