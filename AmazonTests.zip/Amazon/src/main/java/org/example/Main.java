package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.com.tr/");
        driver.manage().window().maximize();
        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//input[@name='accept']")).click();

        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("vestel");
        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }
        driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();

        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0,8000)");

        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }


        for (int i = 1; i < 7; i++) {
            List<WebElement> a=driver.findElements(By.xpath("//div[contains(@class,'a-section a-spacing-base')]"));
            for(WebElement item:a){
                String name=item.findElement(By.tagName("h2")).getText();
                if (name.trim().toLowerCase().equals("vestel") || name.trim().toLowerCase().contains("vestel") ) {

                }
                else{
                    System.out.println(name+" adlı üründe aratılan kelime yok");
                }
            }
            try
            {
                Thread.sleep(1000);
            }
            catch (InterruptedException e)
            {
                throw new RuntimeException(e);
            }

            driver.findElement(By.xpath("//a[contains(@class,'s-pagination-next')]")).click();
        }
        driver.quit();



    }
}